   const questionData = {
  general: {
    easy: [
  {
    question: "What is the capital of India?",
    options: ["Mumbai", "New Delhi", "Chennai", "Kolkata"],
    answer: "New Delhi"
  },
  {
    question: "How many days are there in a leap year?",
    options: ["364", "365", "366", "367"],
    answer: "366"
  },
  {
    question: "Who wrote the national anthem of India?",
    options: ["Mahatma Gandhi", "Jawaharlal Nehru", "Rabindranath Tagore", "Sarojini Naidu"],
    answer: "Rabindranath Tagore"
  },
  {
    question: "Which planet is known as the Red Planet?",
    options: ["Earth", "Venus", "Mars", "Jupiter"],
    answer: "Mars"
  },
  {
    question: "What is the largest animal on Earth?",
    options: ["Elephant", "Giraffe", "Blue Whale", "Shark"],
    answer: "Blue Whale"
  },
  {
    question: "Which gas do plants absorb from the atmosphere?",
    options: ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"],
    answer: "Carbon Dioxide"
  },
  {
    question: "What is the currency of Japan?",
    options: ["Won", "Dollar", "Yen", "Ringgit"],
    answer: "Yen"
  },
  {
    question: "Which festival is known as the Festival of Lights in India?",
    options: ["Holi", "Pongal", "Diwali", "Eid"],
    answer: "Diwali"
  },
  {
    question: "How many continents are there on Earth?",
    options: ["5", "6", "7", "8"],
    answer: "7"
  },
  {
    question: "Which part of the plant conducts photosynthesis?",
    options: ["Root", "Stem", "Leaf", "Flower"],
    answer: "Leaf"
  },
  {
    question: "What do bees produce?",
    options: ["Milk", "Wax", "Silk", "Honey"],
    answer: "Honey"
  },
  {
    question: "Who is the President of India as of 2025?",
    options: ["Narendra Modi", "Ram Nath Kovind", "Droupadi Murmu", "Pratibha Patil"],
    answer: "Droupadi Murmu"
  },
  {
    question: "What is the boiling point of water?",
    options: ["50°C", "90°C", "100°C", "150°C"],
    answer: "100°C"
  },
  {
    question: "Which is the smallest month of the year?",
    options: ["January", "February", "March", "June"],
    answer: "February"
  },
  {
    question: "Which bird is known for its colorful feathers and dancing?",
    options: ["Sparrow", "Pigeon", "Peacock", "Owl"],
    answer: "Peacock"
  },
  {
    question: "Who invented the electric bulb?",
    options: ["Isaac Newton", "Thomas Edison", "Albert Einstein", "Nikola Tesla"],
    answer: "Thomas Edison"
  },
  {
    question: "Which organ pumps blood in the human body?",
    options: ["Liver", "Brain", "Kidney", "Heart"],
    answer: "Heart"
  },
  {
    question: "Which ocean is the largest in the world?",
    options: ["Atlantic", "Indian", "Pacific", "Arctic"],
    answer: "Pacific"
  },
  {
    question: "How many players are there in a cricket team?",
    options: ["10", "11", "12", "9"],
    answer: "11"
  },
  {
    question: "What is the national fruit of India?",
    options: ["Banana", "Apple", "Mango", "Orange"],
    answer: "Mango"
  }
],

    medium: [
  {
    question: "Which Mughal emperor built the Taj Mahal?",
    options: ["Akbar", "Humayun", "Shah Jahan", "Aurangzeb"],
    answer: "Shah Jahan"
  },
  {
    question: "What is the smallest bone in the human body?",
    options: ["Femur", "Stapes", "Radius", "Ulna"],
    answer: "Stapes"
  },
  {
    question: "Which country is also known as the Land of the Rising Sun?",
    options: ["China", "South Korea", "Japan", "Thailand"],
    answer: "Japan"
  },
  {
    question: "Who was the first Indian to go to space?",
    options: ["Rakesh Sharma", "Kalpana Chawla", "Sunita Williams", "Vikram Sarabhai"],
    answer: "Rakesh Sharma"
  },
  {
    question: "What is the hardest natural substance on Earth?",
    options: ["Steel", "Quartz", "Graphite", "Diamond"],
    answer: "Diamond"
  },
  {
    question: "Who discovered penicillin?",
    options: ["Alexander Fleming", "Louis Pasteur", "Isaac Newton", "Albert Einstein"],
    answer: "Alexander Fleming"
  },
  {
    question: "In which year did India gain independence?",
    options: ["1945", "1947", "1950", "1952"],
    answer: "1947"
  },
  {
    question: "Which is the longest river in the world?",
    options: ["Amazon", "Nile", "Yangtze", "Mississippi"],
    answer: "Nile"
  },
  {
    question: "What is the chemical symbol of gold?",
    options: ["Au", "Ag", "Go", "Gd"],
    answer: "Au"
  },
  {
    question: "Which state in India has the highest literacy rate (as of latest census)?",
    options: ["Kerala", "Tamil Nadu", "Maharashtra", "Delhi"],
    answer: "Kerala"
  },
  {
    question: "Which scientist developed the theory of relativity?",
    options: ["Newton", "Galileo", "Einstein", "Bohr"],
    answer: "Einstein"
  },
  {
    question: "Which vitamin is produced when the human skin is exposed to sunlight?",
    options: ["Vitamin A", "Vitamin B", "Vitamin C", "Vitamin D"],
    answer: "Vitamin D"
  },
  {
    question: "Which is the national aquatic animal of India?",
    options: ["Sea Turtle", "Blue Whale", "River Dolphin", "Crocodile"],
    answer: "River Dolphin"
  },
  {
    question: "What is the SI unit of force?",
    options: ["Joule", "Watt", "Newton", "Pascal"],
    answer: "Newton"
  },
  {
    question: "Which Indian city is known as the 'City of Lakes'?",
    options: ["Jaipur", "Udaipur", "Mysore", "Bhopal"],
    answer: "Udaipur"
  },
  {
    question: "What is the full form of DNA?",
    options: ["Deoxyribonucleic Acid", "Deoxyribose Nucleic Agent", "Dynamic Nucleic Acid", "Double Helix Nucleic Acid"],
    answer: "Deoxyribonucleic Acid"
  },
  {
    question: "Which instrument is used to measure earthquakes?",
    options: ["Thermometer", "Barometer", "Seismograph", "Hydrometer"],
    answer: "Seismograph"
  },
  {
    question: "Which Indian freedom fighter is known as 'Netaji'?",
    options: ["Bhagat Singh", "Jawaharlal Nehru", "Subhas Chandra Bose", "Lala Lajpat Rai"],
    answer: "Subhas Chandra Bose"
  },
  {
    question: "Which continent has the most number of countries?",
    options: ["Asia", "Europe", "Africa", "South America"],
    answer: "Africa"
  },
  {
    question: "Who is the author of 'Wings of Fire'?",
    options: ["C.V. Raman", "Abdul Kalam", "Vikram Sarabhai", "A.P.J. Abdul Kalam"],
    answer: "A.P.J. Abdul Kalam"
  }
],

    difficult: [
  {
    question: "Which is the oldest known civilization in the world?",
    options: ["Mesopotamian", "Indus Valley", "Egyptian", "Chinese"],
    answer: "Mesopotamian"
  },
  {
    question: "Who coined the term 'Zero' as a number?",
    options: ["Aryabhata", "Brahmagupta", "Bhaskara I", "Ramanujan"],
    answer: "Brahmagupta"
  },
  {
    question: "What is the name of the world’s first artificial satellite?",
    options: ["Voyager 1", "Sputnik 1", "Aryabhata", "Explorer 1"],
    answer: "Sputnik 1"
  },
  {
    question: "Which element has the highest melting point?",
    options: ["Platinum", "Iron", "Tungsten", "Osmium"],
    answer: "Tungsten"
  },
  {
    question: "Which country has won the most Nobel Prizes in Literature?",
    options: ["United States", "France", "Germany", "Russia"],
    answer: "France"
  },
  {
    question: "In which year was the United Nations established?",
    options: ["1919", "1939", "1945", "1950"],
    answer: "1945"
  },
  {
    question: "Which Indian scientist won the Nobel Prize in Physics in 1930?",
    options: ["Homi Bhabha", "C.V. Raman", "S. Chandrasekhar", "Meghnad Saha"],
    answer: "C.V. Raman"
  },
  {
    question: "What is the study of fungi called?",
    options: ["Botany", "Ecology", "Mycology", "Zoology"],
    answer: "Mycology"
  },
  {
    question: "Which planet has the most moons?",
    options: ["Earth", "Jupiter", "Saturn", "Uranus"],
    answer: "Saturn"
  },
  {
    question: "Which war was fought between North and South Korea?",
    options: ["Vietnam War", "Korean War", "Gulf War", "Cold War"],
    answer: "Korean War"
  },
  {
    question: "Which is the deepest point in the ocean?",
    options: ["Tonga Trench", "Mariana Trench", "Philippine Trench", "Sunda Trench"],
    answer: "Mariana Trench"
  },
  {
    question: "What is the capital of the African country Zimbabwe?",
    options: ["Harare", "Lusaka", "Gaborone", "Kigali"],
    answer: "Harare"
  },
  {
    question: "Which Mughal emperor was also known as Alamgir?",
    options: ["Akbar", "Shah Jahan", "Aurangzeb", "Babur"],
    answer: "Aurangzeb"
  },
  {
    question: "Who developed the heliocentric model of the solar system?",
    options: ["Galileo Galilei", "Copernicus", "Kepler", "Newton"],
    answer: "Copernicus"
  },
  {
    question: "What is the longest bone in the human body?",
    options: ["Tibia", "Humerus", "Femur", "Fibula"],
    answer: "Femur"
  },
  {
    question: "Which Indian classical dance originated in Odisha?",
    options: ["Kathak", "Bharatanatyam", "Odissi", "Manipuri"],
    answer: "Odissi"
  },
  {
    question: "Which ancient Indian text is known for its teachings on diplomacy and politics?",
    options: ["Arthashastra", "Ramayana", "Mahabharata", "Rigveda"],
    answer: "Arthashastra"
  },
  {
    question: "What is the capital of the Canadian province of British Columbia?",
    options: ["Toronto", "Vancouver", "Calgary", "Victoria"],
    answer: "Victoria"
  },
  {
    question: "What is the full form of RADAR?",
    options: ["Radio Detection and Ranging", "Rapid Data and Recording", "Remote Analysis and Response", "Radiant Direction and Range"],
    answer: "Radio Detection and Ranging"
  },
  {
    question: "Which is the largest desert in the world?",
    options: ["Gobi", "Sahara", "Kalahari", "Antarctica"],
    answer: "Antarctica"
  }
],

   hard: [
  {
    question: "Which language is considered the oldest written language still in use today?",
    options: ["Greek", "Hebrew", "Tamil", "Latin"],
    answer: "Tamil"
  },
  {
    question: "Which is the only country in the world to have a flag that is not rectangular or square?",
    options: ["Nepal", "Bhutan", "Vatican City", "Sri Lanka"],
    answer: "Nepal"
  },
  {
    question: "What is the name of the theoretical boundary around a black hole beyond which nothing can escape?",
    options: ["Event Horizon", "Gravity Shell", "Dark Limit", "Singularity Ring"],
    answer: "Event Horizon"
  },
  {
    question: "Which element has the highest electrical conductivity at room temperature?",
    options: ["Gold", "Copper", "Silver", "Platinum"],
    answer: "Silver"
  },
  {
    question: "Which famous battle in 331 BCE led to the downfall of the Persian Empire?",
    options: ["Battle of Marathon", "Battle of Gaugamela", "Battle of Thermopylae", "Battle of Salamis"],
    answer: "Battle of Gaugamela"
  },
  {
    question: "What is the name of the structure in human DNA where the two strands twist around each other?",
    options: ["Alpha Helix", "Spiral Coil", "Double Helix", "Molecular Loop"],
    answer: "Double Helix"
  },
  {
    question: "Who was the first woman to win a Nobel Prize?",
    options: ["Marie Curie", "Rosalind Franklin", "Dorothy Hodgkin", "Ada Lovelace"],
    answer: "Marie Curie"
  },
  {
    question: "Which mathematical theorem proves that no three positive integers can satisfy the equation a³ + b³ = c³?",
    options: ["Euler’s Theorem", "Fermat’s Last Theorem", "Pythagorean Theorem", "Lagrange’s Theorem"],
    answer: "Fermat’s Last Theorem"
  },
  {
    question: "Which country has the most natural lakes in the world?",
    options: ["Russia", "Canada", "Brazil", "USA"],
    answer: "Canada"
  },
  {
    question: "Who developed the first successful polio vaccine in the 1950s?",
    options: ["Edward Jenner", "Jonas Salk", "Louis Pasteur", "Alexander Fleming"],
    answer: "Jonas Salk"
  },
  {
    question: "Which civilization built the Machu Picchu complex in Peru?",
    options: ["Maya", "Aztec", "Inca", "Olmec"],
    answer: "Inca"
  },
  {
    question: "In which organelle of the cell does photosynthesis occur?",
    options: ["Mitochondria", "Ribosome", "Chloroplast", "Golgi body"],
    answer: "Chloroplast"
  },
  {
    question: "Which treaty ended World War I?",
    options: ["Treaty of Paris", "Treaty of Versailles", "Treaty of Ghent", "Treaty of Vienna"],
    answer: "Treaty of Versailles"
  },
  {
    question: "Who was the first Indian to receive a Nobel Prize?",
    options: ["C.V. Raman", "Rabindranath Tagore", "Mother Teresa", "Amartya Sen"],
    answer: "Rabindranath Tagore"
  },
  {
    question: "Which Indian mathematician made pioneering contributions to number theory with little formal training?",
    options: ["Satyendra Nath Bose", "Aryabhata", "Ramanujan", "Bhaskara II"],
    answer: "Ramanujan"
  },
  {
    question: "What is the capital of Kazakhstan?",
    options: ["Almaty", "Astana (now Nur-Sultan)", "Tashkent", "Bishkek"],
    answer: "Astana (now Nur-Sultan)"
  },
  {
    question: "Which is the only continent without a desert?",
    options: ["Europe", "Asia", "South America", "Australia"],
    answer: "Europe"
  },
  {
    question: "Which planet in the solar system rotates in the opposite direction to most other planets?",
    options: ["Mercury", "Mars", "Uranus", "Venus"],
    answer: "Venus"
  },
  {
    question: "Which rare gas glows red-orange in a vacuum tube and is used in neon signs?",
    options: ["Argon", "Krypton", "Neon", "Xenon"],
    answer: "Neon"
  },
  {
    question: "Who painted the ceiling of the Sistine Chapel in Vatican City?",
    options: ["Leonardo da Vinci", "Michelangelo", "Raphael", "Donatello"],
    answer: "Michelangelo"
  }
]

  },
  history: {
   easy: [
  {
    question: "Who was the first Prime Minister of independent India?",
    options: ["Mahatma Gandhi", "Jawaharlal Nehru", "Sardar Patel", "Lal Bahadur Shastri"],
    answer: "Jawaharlal Nehru"
  },
  {
    question: "In which year did India become independent from British rule?",
    options: ["1945", "1947", "1950", "1952"],
    answer: "1947"
  },
  {
    question: "Who founded the Maurya Empire in India?",
    options: ["Ashoka", "Chandragupta Maurya", "Harsha", "Samudragupta"],
    answer: "Chandragupta Maurya"
  },
  {
    question: "The Taj Mahal was built by which Mughal emperor?",
    options: ["Akbar", "Jahangir", "Shah Jahan", "Aurangzeb"],
    answer: "Shah Jahan"
  },
  {
    question: "Which Indian freedom fighter is known as the ‘Iron Man of India’?",
    options: ["Subhas Chandra Bose", "Sardar Vallabhbhai Patel", "Bhagat Singh", "Jawaharlal Nehru"],
    answer: "Sardar Vallabhbhai Patel"
  },
  {
    question: "What was the main objective of the Non-Cooperation Movement?",
    options: ["To fight World War I", "To boycott British goods and institutions", "To draft the Indian Constitution", "To establish a new government"],
    answer: "To boycott British goods and institutions"
  },
  {
    question: "Which city was the capital of the Gupta Empire?",
    options: ["Pataliputra", "Taxila", "Ujjain", "Kannauj"],
    answer: "Pataliputra"
  },
  {
    question: "Who was the last Mughal emperor of India?",
    options: ["Bahadur Shah Zafar", "Akbar II", "Aurangzeb", "Jahangir"],
    answer: "Bahadur Shah Zafar"
  },
  {
    question: "Which Indian leader gave the famous ‘Quit India’ speech in 1942?",
    options: ["Mahatma Gandhi", "Jawaharlal Nehru", "Subhas Chandra Bose", "Bal Gangadhar Tilak"],
    answer: "Mahatma Gandhi"
  },
  {
    question: "Which ancient Indian university was one of the oldest centers of learning?",
    options: ["Nalanda", "Takshashila", "Vikramashila", "Kashi"],
    answer: "Takshashila"
  },
  {
    question: "The Battle of Plassey was fought in which year?",
    options: ["1757", "1764", "1776", "1789"],
    answer: "1757"
  },
  {
    question: "Who was the first Indian to win the Nobel Prize?",
    options: ["C.V. Raman", "Rabindranath Tagore", "Mother Teresa", "Amartya Sen"],
    answer: "Rabindranath Tagore"
  },
  {
    question: "Which event is known as the start of World War II?",
    options: ["Invasion of Poland by Germany", "Bombing of Pearl Harbor", "Assassination of Archduke Franz Ferdinand", "Battle of Britain"],
    answer: "Invasion of Poland by Germany"
  },
  {
    question: "Who was the first woman Prime Minister of India?",
    options: ["Indira Gandhi", "Sarojini Naidu", "Pratibha Patil", "Sonia Gandhi"],
    answer: "Indira Gandhi"
  },
  {
    question: "The ‘Salt March’ was led by which leader?",
    options: ["Jawaharlal Nehru", "Subhas Chandra Bose", "Mahatma Gandhi", "Bhagat Singh"],
    answer: "Mahatma Gandhi"
  },
  {
    question: "Which empire did Akbar the Great belong to?",
    options: ["Gupta Empire", "Mughal Empire", "Maurya Empire", "Chola Empire"],
    answer: "Mughal Empire"
  },
  {
    question: "The Indian National Congress was founded in which year?",
    options: ["1875", "1885", "1905", "1919"],
    answer: "1885"
  },
  {
    question: "Which country was ruled by Napoleon Bonaparte?",
    options: ["Spain", "France", "Italy", "Germany"],
    answer: "France"
  },
  {
    question: "Who was the first President of independent India?",
    options: ["Jawaharlal Nehru", "Rajendra Prasad", "Sardar Patel", "Zakir Hussain"],
    answer: "Rajendra Prasad"
  },
  {
    question: "The famous 'Iron Pillar' is located in which Indian city?",
    options: ["Delhi", "Jaipur", "Mumbai", "Chennai"],
    answer: "Delhi"
  }
],
    medium: [
  {
    question: "Who was the founder of the Mughal Empire in India?",
    options: ["Babur", "Akbar", "Humayun", "Shah Jahan"],
    answer: "Babur"
  },
  {
    question: "The Rowlatt Act, which allowed the British government to imprison people without trial, was enacted in which year?",
    options: ["1917", "1919", "1920", "1922"],
    answer: "1919"
  },
  {
    question: "Which Indian leader formed the Forward Bloc after leaving the Indian National Congress?",
    options: ["Jawaharlal Nehru", "Subhas Chandra Bose", "Bal Gangadhar Tilak", "Lala Lajpat Rai"],
    answer: "Subhas Chandra Bose"
  },
  {
    question: "The Doctrine of Lapse was introduced by which British Governor-General?",
    options: ["Lord Dalhousie", "Lord Curzon", "Lord Cornwallis", "Lord Wellesley"],
    answer: "Lord Dalhousie"
  },
  {
    question: "Who wrote the ancient Indian epic ‘Mahabharata’?",
    options: ["Valmiki", "Vyasa", "Kalidasa", "Tulsidas"],
    answer: "Vyasa"
  },
  {
    question: "The Indian Rebellion of 1857 is also known by what other name?",
    options: ["The Sepoy Mutiny", "The Great War", "The Civil Disobedience Movement", "The Quit India Movement"],
    answer: "The Sepoy Mutiny"
  },
  {
    question: "Which treaty ended the First Anglo-Maratha War?",
    options: ["Treaty of Salbai", "Treaty of Paris", "Treaty of Allahabad", "Treaty of Seringapatam"],
    answer: "Treaty of Salbai"
  },
  {
    question: "Who was the Viceroy of India during the partition of Bengal in 1905?",
    options: ["Lord Curzon", "Lord Mountbatten", "Lord Wavell", "Lord Ripon"],
    answer: "Lord Curzon"
  },
  {
    question: "Which Indian king is famous for his rock edicts and spreading Buddhism?",
    options: ["Chandragupta Maurya", "Ashoka", "Harsha", "Samudragupta"],
    answer: "Ashoka"
  },
  {
    question: "Who was the first Indian woman to become the President of the Indian National Congress?",
    options: ["Sarojini Naidu", "Annie Besant", "Indira Gandhi", "Kamala Nehru"],
    answer: "Sarojini Naidu"
  },
  {
    question: "Which European country colonized Goa before it became part of India?",
    options: ["France", "Portugal", "Netherlands", "Spain"],
    answer: "Portugal"
  },
  {
    question: "The Salem witch trials took place in which country?",
    options: ["England", "Germany", "USA", "France"],
    answer: "USA"
  },
  {
    question: "The Berlin Wall was constructed in which year?",
    options: ["1945", "1955", "1961", "1975"],
    answer: "1961"
  },
  {
    question: "Who was the author of the book ‘The Discovery of India’?",
    options: ["Jawaharlal Nehru", "Rabindranath Tagore", "Mahatma Gandhi", "Sardar Patel"],
    answer: "Jawaharlal Nehru"
  },
  {
    question: "Which empire built the ancient city of Hampi?",
    options: ["Vijayanagara Empire", "Mughal Empire", "Gupta Empire", "Chola Empire"],
    answer: "Vijayanagara Empire"
  },
  {
    question: "Who was the first Indian to win an Olympic gold medal?",
    options: ["Milkha Singh", "Abhinav Bindra", "Norman Pritchard", "Dhyan Chand"],
    answer: "Norman Pritchard"
  },
  {
    question: "What was the main purpose of the Salt March led by Gandhi in 1930?",
    options: ["To protest against the British salt tax", "To promote Indian textiles", "To start a war with Britain", "To support World War II"],
    answer: "To protest against the British salt tax"
  },
  {
    question: "Who was the first woman ruler of Delhi Sultanate?",
    options: ["Razia Sultana", "Nur Jahan", "Jahanara Begum", "Mumtaz Mahal"],
    answer: "Razia Sultana"
  },
  {
    question: "Which treaty marked the beginning of British rule in India after the Battle of Plassey?",
    options: [
      "Treaty of Allahabad",
      "Treaty of Paris",
      "Treaty of Seringapatam",
      "None; Battle of Plassey led to British East India Company control"
    ],
    answer: "None; Battle of Plassey led to British East India Company control"
  },
  {
    question: "Who was the British Viceroy during the Quit India Movement in 1942?",
    options: ["Lord Mountbatten", "Lord Linlithgow", "Lord Curzon", "Lord Wavell"],
    answer: "Lord Linlithgow"
  }
],
    difficult: [
  {
    question: "Who was the architect of the Indian Constitution?",
    options: ["Jawaharlal Nehru", "B. R. Ambedkar", "Sardar Patel", "Rajendra Prasad"],
    answer: "B. R. Ambedkar"
  },
  {
    question: "The Battle of Buxar (1764) was fought between the British East India Company and which alliance?",
    options: [
      "Marathas and Sikhs",
      "Nawab of Bengal, Nawab of Awadh, and Mughal Emperor",
      "French East India Company and Mysore Kingdom",
      "Marathas and Mysore Kingdom"
    ],
    answer: "Nawab of Bengal, Nawab of Awadh, and Mughal Emperor"
  },
  {
    question: "The Treaty of Versailles (1919) ended which major conflict?",
    options: ["World War I", "World War II", "Crimean War", "Franco-Prussian War"],
    answer: "World War I"
  },
  {
    question: "Who was the founder of the Mauryan Empire’s capital city Pataliputra?",
    options: ["Chandragupta Maurya", "Ashoka", "Bindusara", "Harsha"],
    answer: "Chandragupta Maurya"
  },
  {
    question: "The Berlin Conference (1884-1885) dealt with the colonization of which continent?",
    options: ["Asia", "Africa", "South America", "Australia"],
    answer: "Africa"
  },
  {
    question: "Which Indian leader gave the ‘Tryst with Destiny’ speech at the time of India’s independence?",
    options: ["Mahatma Gandhi", "Jawaharlal Nehru", "Sardar Patel", "B. R. Ambedkar"],
    answer: "Jawaharlal Nehru"
  },
  {
    question: "The Sepoy Mutiny of 1857 began in which cantonment?",
    options: ["Meerut", "Delhi", "Lucknow", "Kanpur"],
    answer: "Meerut"
  },
  {
    question: "Who was the ruler of the Gupta Empire at its zenith?",
    options: ["Chandragupta I", "Samudragupta", "Skandagupta", "Kumaragupta"],
    answer: "Samudragupta"
  },
  {
    question: "The League of Nations was formed after which war?",
    options: ["World War I", "World War II", "Korean War", "Vietnam War"],
    answer: "World War I"
  },
  {
    question: "Who was the last Governor-General of independent India?",
    options: ["Lord Mountbatten", "Chakravarti Rajagopalachari", "Rajendra Prasad", "Sardar Patel"],
    answer: "Chakravarti Rajagopalachari"
  },
  {
    question: "The ‘Doctrine of Lapse’ was annulled by which act?",
    options: [
      "Indian Councils Act 1861",
      "Government of India Act 1858",
      "Indian Rebellion of 1857",
      "The Indian Succession Act 1870"
    ],
    answer: "Government of India Act 1858"
  },
  {
    question: "The Cuban Missile Crisis occurred in which year?",
    options: ["1959", "1961", "1962", "1965"],
    answer: "1962"
  },
  {
    question: "Which Indian emperor converted to Buddhism after the Kalinga War?",
    options: ["Chandragupta Maurya", "Ashoka", "Samudragupta", "Harsha"],
    answer: "Ashoka"
  },
  {
    question: "The Versailles Treaty required Germany to pay reparations after which war?",
    options: ["World War I", "World War II", "Crimean War", "Napoleonic Wars"],
    answer: "World War I"
  },
  {
    question: "Who was the leader of the Soviet Union during the Cuban Missile Crisis?",
    options: ["Joseph Stalin", "Nikita Khrushchev", "Leonid Brezhnev", "Mikhail Gorbachev"],
    answer: "Nikita Khrushchev"
  },
  {
    question: "The Battle of Panipat (1526) marked the beginning of which dynasty in India?",
    options: ["Gupta", "Mughal", "Maurya", "Chola"],
    answer: "Mughal"
  },
  {
    question: "Which British Prime Minister declared “Peace for our time” before WWII?",
    options: ["Winston Churchill", "Neville Chamberlain", "Clement Attlee", "Stanley Baldwin"],
    answer: "Neville Chamberlain"
  },
  {
    question: "Who was the main architect of the Non-Aligned Movement?",
    options: ["Jawaharlal Nehru", "Mahatma Gandhi", "Indira Gandhi", "Subhas Chandra Bose"],
    answer: "Jawaharlal Nehru"
  },
  {
    question: "Which war was fought between the United States and the Soviet Union indirectly through other countries?",
    options: ["Cold War", "World War II", "Korean War", "Vietnam War"],
    answer: "Cold War"
  },
  {
    question: "Who was the first Indian woman to become the Governor of an Indian state?",
    options: ["Sarojini Naidu", "Vijayalakshmi Pandit", "Sucheta Kriplani", "Indira Gandhi"],
    answer: "Sarojini Naidu"
  }
],
    hard: [
  {
    question: "Which ancient Indian text is considered the earliest treatise on statecraft and diplomacy?",
    options: ["Arthashastra", "Manusmriti", "Ramayana", "Mahabharata"],
    answer: "Arthashastra"
  },
  {
    question: "Who was the ruler of the Satavahana dynasty during its greatest expansion?",
    options: ["Gautamiputra Satakarni", "Pulakeshin II", "Kharavela", "Harsha"],
    answer: "Gautamiputra Satakarni"
  },
  {
    question: "The Battle of Talikota (1565) led to the fall of which empire?",
    options: ["Vijayanagara Empire", "Mughal Empire", "Maratha Empire", "Gupta Empire"],
    answer: "Vijayanagara Empire"
  },
  {
    question: "Which Mughal emperor was known for his interest in art and established the Shalimar Gardens?",
    options: ["Jahangir", "Shah Jahan", "Akbar", "Aurangzeb"],
    answer: "Jahangir"
  },
  {
    question: "The ‘Doctrine of Necessity’ was invoked to legitimize which political event?",
    options: [
      "Emergency in India (1975)",
      "Dismissal of the Punjab Government (1983)",
      "Annexation of Sikkim (1975)",
      "Formation of Bangladesh (1971)"
    ],
    answer: "Emergency in India (1975)"
  },
  {
    question: "Who wrote ‘The History of British India’, a comprehensive account of the British colonial period?",
    options: ["James Mill", "William Jones", "Thomas Macaulay", "John Keay"],
    answer: "James Mill"
  },
  {
    question: "Which ancient civilization is associated with the city of Dholavira?",
    options: ["Harappan Civilization", "Mauryan Empire", "Gupta Empire", "Vedic Civilization"],
    answer: "Harappan Civilization"
  },
  {
    question: "The Treaty of Nanking (1842) ended which war?",
    options: ["First Opium War", "Second Opium War", "Sino-Japanese War", "Boxer Rebellion"],
    answer: "First Opium War"
  },
  {
    question: "Who was the longest-reigning British monarch before Queen Elizabeth II?",
    options: ["Queen Victoria", "King George III", "Queen Anne", "King Henry VIII"],
    answer: "Queen Victoria"
  },
  {
    question: "The Khilafat Movement in India was primarily aimed at protecting which empire?",
    options: ["Ottoman Empire", "British Empire", "Mughal Empire", "Persian Empire"],
    answer: "Ottoman Empire"
  },
  {
    question: "Which Indian dynasty is known for the cave temples of Ellora?",
    options: ["Rashtrakuta", "Chola", "Pallava", "Gupta"],
    answer: "Rashtrakuta"
  },
  {
    question: "The Congress Socialist Party was formed in which year?",
    options: ["1934", "1925", "1942", "1919"],
    answer: "1934"
  },
  {
    question: "The Zimmerman Telegram was a secret diplomatic communication during which war?",
    options: ["World War I", "World War II", "Cold War", "Spanish-American War"],
    answer: "World War I"
  },
  {
    question: "Who was the British Viceroy when the Indian National Army was formed?",
    options: ["Lord Linlithgow", "Lord Wavell", "Lord Mountbatten", "Lord Curzon"],
    answer: "Lord Linlithgow"
  },
  {
    question: "The Peace of Westphalia (1648) ended which conflict?",
    options: ["Thirty Years' War", "Hundred Years' War", "Napoleonic Wars", "Franco-Prussian War"],
    answer: "Thirty Years' War"
  },
  {
    question: "Which Indian revolutionary group assassinated British official Lord Mayo?",
    options: ["Anushilan Samiti", "Hindustan Socialist Republican Association", "Ghadar Party", "Indian National Army"],
    answer: "Anushilan Samiti"
  },
  {
    question: "The Edicts of Ashoka were primarily written in which script?",
    options: ["Brahmi", "Kharosthi", "Devanagari", "Tamil-Brahmi"],
    answer: "Brahmi"
  },
  {
    question: "Who was the first Secretary-General of the United Nations?",
    options: ["Trygve Lie", "Dag Hammarskjöld", "U Thant", "Kofi Annan"],
    answer: "Trygve Lie"
  },
  {
    question: "Which battle marked the end of the Mughal Empire’s dominance in India?",
    options: ["Battle of Plassey", "Battle of Panipat (1761)", "Battle of Buxar", "Battle of Wandiwash"],
    answer: "Battle of Panipat (1761)"
  },
  {
    question: "The ‘Doctrine of Lapse’ was a policy introduced by which British Governor-General?",
    options: ["Lord Dalhousie", "Lord Wellesley", "Lord Curzon", "Lord Cornwallis"],
    answer: "Lord Dalhousie"
  }
]
  },
  science: {
    easy: [
  {
    question: "What is the process by which plants make their own food?",
    options: ["Photosynthesis", "Respiration", "Transpiration", "Digestion"],
    answer: "Photosynthesis"
  },
  {
    question: "Which gas do plants take in during photosynthesis?",
    options: ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"],
    answer: "Carbon dioxide"
  },
  {
    question: "What is the boiling point of water at sea level?",
    options: ["50°C", "100°C", "150°C", "200°C"],
    answer: "100°C"
  },
  {
    question: "Which organ pumps blood throughout the human body?",
    options: ["Brain", "Lungs", "Heart", "Liver"],
    answer: "Heart"
  },
  {
    question: "What is the largest planet in our Solar System?",
    options: ["Earth", "Mars", "Jupiter", "Saturn"],
    answer: "Jupiter"
  },
  {
    question: "Which natural resource is used to make glass?",
    options: ["Sand", "Clay", "Limestone", "Coal"],
    answer: "Sand"
  },
  {
    question: "What do bees collect from flowers to make honey?",
    options: ["Nectar", "Pollen", "Water", "Leaves"],
    answer: "Nectar"
  },
  {
    question: "Which is the fastest land animal?",
    options: ["Lion", "Cheetah", "Tiger", "Leopard"],
    answer: "Cheetah"
  },
  {
    question: "Which part of the plant absorbs water from the soil?",
    options: ["Stem", "Leaf", "Root", "Flower"],
    answer: "Root"
  },
  {
    question: "What kind of animal is a frog?",
    options: ["Mammal", "Reptile", "Amphibian", "Bird"],
    answer: "Amphibian"
  },
  {
    question: "Which gas is most abundant in the Earth's atmosphere?",
    options: ["Oxygen", "Nitrogen", "Carbon dioxide", "Argon"],
    answer: "Nitrogen"
  },
  {
    question: "Which planet is known as the Red Planet?",
    options: ["Venus", "Mars", "Mercury", "Neptune"],
    answer: "Mars"
  },
  {
    question: "What do we call animals that eat only plants?",
    options: ["Carnivores", "Herbivores", "Omnivores", "Insectivores"],
    answer: "Herbivores"
  },
  {
    question: "What is the center of an atom called?",
    options: ["Electron", "Proton", "Nucleus", "Neutron"],
    answer: "Nucleus"
  },
  {
    question: "Which natural phenomenon causes the shaking of the Earth?",
    options: ["Tsunami", "Earthquake", "Tornado", "Flood"],
    answer: "Earthquake"
  },
  {
    question: "What is the main source of energy for Earth?",
    options: ["Moon", "Stars", "Sun", "Wind"],
    answer: "Sun"
  },
  {
    question: "Which part of the human body controls our thoughts?",
    options: ["Heart", "Brain", "Lungs", "Kidney"],
    answer: "Brain"
  },
  {
    question: "Which vitamin is produced when the skin is exposed to sunlight?",
    options: ["Vitamin A", "Vitamin B", "Vitamin C", "Vitamin D"],
    answer: "Vitamin D"
  },
  {
    question: "Which layer of the Earth is liquid?",
    options: ["Crust", "Mantle", "Outer Core", "Inner Core"],
    answer: "Outer Core"
  },
  {
    question: "What is the chemical symbol for water?",
    options: ["CO2", "O2", "H2O", "NaCl"],
    answer: "H2O"
  }
],
    medium: [
  {
    question: "Which gas is responsible for the greenhouse effect and global warming?",
    options: ["Oxygen", "Nitrogen", "Carbon dioxide", "Argon"],
    answer: "Carbon dioxide"
  },
  {
    question: "What type of bond involves the sharing of electron pairs between atoms?",
    options: ["Ionic bond", "Covalent bond", "Metallic bond", "Hydrogen bond"],
    answer: "Covalent bond"
  },
  {
    question: "Which organelle is known as the powerhouse of the cell?",
    options: ["Nucleus", "Ribosome", "Mitochondria", "Endoplasmic reticulum"],
    answer: "Mitochondria"
  },
  {
    question: "What is the chemical formula of glucose?",
    options: ["C6H12O6", "CO2", "H2O", "CH4"],
    answer: "C6H12O6"
  },
  {
    question: "Which blood cells help fight infections?",
    options: ["Red blood cells", "White blood cells", "Platelets", "Plasma"],
    answer: "White blood cells"
  },
  {
    question: "What is the primary function of chlorophyll in plants?",
    options: ["Absorb water", "Absorb sunlight", "Absorb minerals", "Absorb carbon dioxide"],
    answer: "Absorb sunlight"
  },
  {
    question: "Which layer of the atmosphere contains the ozone layer?",
    options: ["Troposphere", "Stratosphere", "Mesosphere", "Thermosphere"],
    answer: "Stratosphere"
  },
  {
    question: "Which element has the atomic number 1?",
    options: ["Oxygen", "Hydrogen", "Helium", "Carbon"],
    answer: "Hydrogen"
  },
  {
    question: "What is the process by which water vapor turns into liquid water?",
    options: ["Evaporation", "Condensation", "Sublimation", "Precipitation"],
    answer: "Condensation"
  },
  {
    question: "What is the human body's largest organ?",
    options: ["Heart", "Liver", "Skin", "Lungs"],
    answer: "Skin"
  },
  {
    question: "Which planet has the most moons in our Solar System?",
    options: ["Earth", "Jupiter", "Saturn", "Mars"],
    answer: "Saturn"
  },
  {
    question: "What is the main gas produced by fermentation?",
    options: ["Oxygen", "Carbon dioxide", "Nitrogen", "Hydrogen"],
    answer: "Carbon dioxide"
  },
  {
    question: "Which vitamin is essential for blood clotting?",
    options: ["Vitamin A", "Vitamin C", "Vitamin K", "Vitamin D"],
    answer: "Vitamin K"
  },
  {
    question: "What type of energy is stored in the bonds of chemical compounds?",
    options: ["Kinetic energy", "Thermal energy", "Chemical energy", "Nuclear energy"],
    answer: "Chemical energy"
  },
  {
    question: "Which part of the brain controls balance and coordination?",
    options: ["Cerebrum", "Cerebellum", "Brainstem", "Hypothalamus"],
    answer: "Cerebellum"
  },
  {
    question: "What is the pH value of pure water?",
    options: ["5", "6", "7", "8"],
    answer: "7"
  },
  {
    question: "What is the term for animals that can regulate their body temperature internally?",
    options: ["Ectotherms", "Endotherms", "Poikilotherms", "Cold-blooded"],
    answer: "Endotherms"
  },
  {
    question: "Which process involves the division of a cell's nucleus?",
    options: ["Mitosis", "Meiosis", "Cytokinesis", "Binary fission"],
    answer: "Mitosis"
  },
  {
    question: "Which metal is liquid at room temperature?",
    options: ["Mercury", "Gold", "Silver", "Copper"],
    answer: "Mercury"
  },
  {
    question: "What is the name of the smallest unit of life?",
    options: ["Atom", "Molecule", "Cell", "Organ"],
    answer: "Cell"
  }
],
    difficult: [
  {
    question: "Which neurotransmitter is primarily associated with mood regulation and happiness?",
    options: ["Dopamine", "Serotonin", "Acetylcholine", "GABA"],
    answer: "Serotonin"
  },
  {
    question: "What is the Heisenberg Uncertainty Principle related to?",
    options: ["Position and momentum of particles", "Energy and time intervals", "Mass and velocity", "Temperature and pressure"],
    answer: "Position and momentum of particles"
  },
  {
    question: "In sociology, what term describes the process by which individuals learn and adopt the norms of their society?",
    options: ["Socialization", "Stratification", "Assimilation", "Ethnocentrism"],
    answer: "Socialization"
  },
  {
    question: "Which economic theory emphasizes total spending in the economy and its effects on output and inflation?",
    options: ["Keynesian economics", "Classical economics", "Monetarism", "Supply-side economics"],
    answer: "Keynesian economics"
  },
  {
    question: "Which part of the brain is most involved in decision-making and executive functions?",
    options: ["Hippocampus", "Amygdala", "Prefrontal cortex", "Thalamus"],
    answer: "Prefrontal cortex"
  },
  {
    question: "In psychology, what is the term for the tendency to attribute one's successes to internal factors and failures to external factors?",
    options: ["Self-serving bias", "Confirmation bias", "Fundamental attribution error", "Cognitive dissonance"],
    answer: "Self-serving bias"
  },
  {
    question: "Which law in physics relates the current flowing through a conductor to the voltage and resistance?",
    options: ["Ohm’s Law", "Newton’s Second Law", "Faraday’s Law", "Boyle’s Law"],
    answer: "Ohm’s Law"
  },
  {
    question: "What is the primary function of ribosomes in a cell?",
    options: ["Energy production", "Protein synthesis", "Waste removal", "DNA replication"],
    answer: "Protein synthesis"
  },
  {
    question: "Which sociological concept refers to a hierarchical arrangement of social classes in a society?",
    options: ["Social stratification", "Social mobility", "Role conflict", "Social norms"],
    answer: "Social stratification"
  },
  {
    question: "In economics, what does the 'invisible hand' concept represent?",
    options: ["Government control of markets", "Self-regulating nature of the market", "Economic monopoly", "Fiscal policy influence"],
    answer: "Self-regulating nature of the market"
  },
  {
    question: "Which type of RNA carries amino acids to the ribosome during protein synthesis?",
    options: ["mRNA", "tRNA", "rRNA", "snRNA"],
    answer: "tRNA"
  },
  {
    question: "What is the principle behind conservation of mass in a chemical reaction?",
    options: ["Mass is created during reaction", "Mass is destroyed during reaction", "Mass remains constant before and after reaction", "Mass depends on temperature"],
    answer: "Mass remains constant before and after reaction"
  },
  {
    question: "Which psychological theory emphasizes the hierarchy of human needs?",
    options: ["Maslow’s hierarchy of needs", "Freud’s psychoanalysis", "Pavlov’s classical conditioning", "Skinner’s operant conditioning"],
    answer: "Maslow’s hierarchy of needs"
  },
  {
    question: "Which sociologist is best known for his work on the division of labor in society?",
    options: ["Max Weber", "Emile Durkheim", "Karl Marx", "Herbert Spencer"],
    answer: "Emile Durkheim"
  },
  {
    question: "In economics, what is the term for a market structure with only one seller?",
    options: ["Oligopoly", "Monopoly", "Perfect competition", "Monopsony"],
    answer: "Monopoly"
  },
  {
    question: "Which gas law states that the pressure of a gas is inversely proportional to its volume at constant temperature?",
    options: ["Charles’s Law", "Boyle’s Law", "Gay-Lussac’s Law", "Avogadro’s Law"],
    answer: "Boyle’s Law"
  },
  {
    question: "What is the term for programmed cell death?",
    options: ["Mitosis", "Apoptosis", "Necrosis", "Cytokinesis"],
    answer: "Apoptosis"
  },
  {
    question: "Which social science field studies the production, distribution, and consumption of goods and services?",
    options: ["Psychology", "Sociology", "Economics", "Anthropology"],
    answer: "Economics"
  },
  {
    question: "What is the psychological phenomenon where people perform better on tasks when in the presence of others?",
    options: ["Social facilitation", "Groupthink", "Bystander effect", "Social loafing"],
    answer: "Social facilitation"
  },
  {
    question: "Which particle in an atom determines the element’s identity?",
    options: ["Neutron", "Electron", "Proton", "Photon"],
    answer: "Proton"
  }
],
    hard: [
  {
    question: "In quantum mechanics, what does the Schrödinger equation describe?",
    options: ["The position of an electron only", "The energy levels of a nucleus", "The wave function and behavior of a quantum system", "The entropy of a closed system"],
    answer: "The wave function and behavior of a quantum system"
  },
  {
    question: "Which brain region is primarily involved in forming and retrieving long-term declarative memories?",
    options: ["Amygdala", "Hippocampus", "Thalamus", "Cerebellum"],
    answer: "Hippocampus"
  },
  {
    question: "What is the sociological term for the unintended consequences of social actions that disrupt social stability?",
    options: ["Manifest functions", "Latent functions", "Dysfunctions", "Social norms"],
    answer: "Dysfunctions"
  },
  {
    question: "In economics, what does the concept of 'moral hazard' refer to?",
    options: ["Risk that one party takes because they do not bear the full consequences", "Market inefficiency due to monopoly", "Inflation caused by excessive demand", "Loss due to natural disasters"],
    answer: "Risk that one party takes because they do not bear the full consequences"
  },
  {
    question: "Which principle states that no two electrons in an atom can have the same set of quantum numbers?",
    options: ["Aufbau principle", "Pauli exclusion principle", "Hund’s rule", "Heisenberg uncertainty principle"],
    answer: "Pauli exclusion principle"
  },
  {
    question: "Which psychological experiment demonstrated obedience to authority figures?",
    options: ["Stanford prison experiment", "Milgram experiment", "Asch conformity experiment", "Bandura’s Bobo doll experiment"],
    answer: "Milgram experiment"
  },
  {
    question: "In particle physics, what is the term for particles that mediate the fundamental forces?",
    options: ["Leptons", "Quarks", "Gauge bosons", "Hadrons"],
    answer: "Gauge bosons"
  },
  {
    question: "What is the main function of the Golgi apparatus in a eukaryotic cell?",
    options: ["Energy production", "Protein modification and packaging", "DNA replication", "Lipid synthesis"],
    answer: "Protein modification and packaging"
  },
  {
    question: "Which sociologist introduced the concept of ‘verstehen’ to understand social action?",
    options: ["Emile Durkheim", "Max Weber", "Karl Marx", "Talcott Parsons"],
    answer: "Max Weber"
  },
  {
    question: "In economics, what does the Laffer Curve illustrate?",
    options: ["The relationship between tax rates and tax revenue", "The trade-off between inflation and unemployment", "The impact of subsidies on supply", "The equilibrium price in a market"],
    answer: "The relationship between tax rates and tax revenue"
  },
  {
    question: "What is the fundamental difference between mitosis and meiosis?",
    options: ["Mitosis results in haploid cells, meiosis in diploid", "Mitosis produces genetically identical cells, meiosis produces genetically diverse cells", "Mitosis occurs only in reproductive organs", "Meiosis is a type of asexual reproduction"],
    answer: "Mitosis produces genetically identical cells, meiosis produces genetically diverse cells"
  },
  {
    question: "Which law in thermodynamics states that entropy of an isolated system never decreases?",
    options: ["Zeroth law", "First law", "Second law", "Third law"],
    answer: "Second law"
  },
  {
    question: "In psychology, what term describes the discomfort experienced when holding two conflicting cognitions?",
    options: ["Cognitive dissonance", "Confirmation bias", "Attribution error", "Self-fulfilling prophecy"],
    answer: "Cognitive dissonance"
  },
  {
    question: "Which sociological theory focuses on power struggles and inequality in society?",
    options: ["Functionalism", "Conflict theory", "Symbolic interactionism", "Structural functionalism"],
    answer: "Conflict theory"
  },
  {
    question: "In economics, what is the ‘elasticity of demand’ a measure of?",
    options: ["Responsiveness of quantity demanded to price changes", "Relationship between supply and demand", "Effect of income on demand", "Government control of prices"],
    answer: "Responsiveness of quantity demanded to price changes"
  },
  {
    question: "What is the unit of electric charge?",
    options: ["Volt", "Coulomb", "Ampere", "Ohm"],
    answer: "Coulomb"
  },
  {
    question: "What is the term for the study of how traits are inherited through genes?",
    options: ["Cytology", "Genetics", "Epigenetics", "Molecular biology"],
    answer: "Genetics"
  },
  {
    question: "Which psychological disorder is characterized by persistent feelings of sadness and loss of interest?",
    options: ["Bipolar disorder", "Schizophrenia", "Major depressive disorder", "Anxiety disorder"],
    answer: "Major depressive disorder"
  },
  {
    question: "Which sociologist is credited with the theory of 'social facts'?",
    options: ["Max Weber", "Karl Marx", "Emile Durkheim", "Herbert Spencer"],
    answer: "Emile Durkheim"
  },
  {
    question: "What is the principle behind the ‘invisible hand’ in classical economics?",
    options: ["Government intervention for market efficiency", "Market self-regulation via individual self-interest", "Price control by monopolies", "Externalities in production"],
    answer: "Market self-regulation via individual self-interest"
  }
]
  },
  sports: {
   easy: [
  {
    question: "Which sport uses a bat and a ball?",
    options: ["Football", "Cricket", "Swimming", "Chess"],
    answer: "Cricket"
  },
  {
    question: "Which country is famous for playing baseball?",
    options: ["India", "Japan", "USA", "Russia"],
    answer: "USA"
  },
  {
    question: "How many players are there in a football team on the field?",
    options: ["10", "9", "11", "12"],
    answer: "11"
  },
  {
    question: "Which sport is played at Wimbledon?",
    options: ["Badminton", "Table Tennis", "Golf", "Tennis"],
    answer: "Tennis"
  },
  {
    question: "What is the color of the card shown by a referee for a serious foul in football?",
    options: ["Green", "Yellow", "Blue", "Red"],
    answer: "Red"
  },
  {
    question: "Which sport is known as “The Gentleman's Game”?",
    options: ["Cricket", "Rugby", "Wrestling", "Boxing"],
    answer: "Cricket"
  },
  {
    question: "Who is a famous Indian cricket player known as the “Master Blaster”?",
    options: ["Virat Kohli", "MS Dhoni", "Sachin Tendulkar", "Rohit Sharma"],
    answer: "Sachin Tendulkar"
  },
  {
    question: "In which sport would you perform a slam dunk?",
    options: ["Volleyball", "Badminton", "Basketball", "Cricket"],
    answer: "Basketball"
  },
  {
    question: "Which country hosted the 2020 Olympic Games (held in 2021)?",
    options: ["China", "Japan", "Brazil", "France"],
    answer: "Japan"
  },
  {
    question: "What is used to hit the shuttlecock in badminton?",
    options: ["Bat", "Paddle", "Racket", "Club"],
    answer: "Racket"
  },
  {
    question: "Which sport uses a net, a ball, and two hands to spike or block?",
    options: ["Football", "Tennis", "Volleyball", "Baseball"],
    answer: "Volleyball"
  },
  {
    question: "In which sport can you score a goal by kicking a ball?",
    options: ["Cricket", "Football", "Golf", "Rugby"],
    answer: "Football"
  },
  {
    question: "Which country is famous for sumo wrestling?",
    options: ["India", "China", "Japan", "Korea"],
    answer: "Japan"
  },
  {
    question: "How many rings are there in the Olympic symbol?",
    options: ["4", "5", "6", "7"],
    answer: "5"
  },
  {
    question: "What sport did Usain Bolt compete in?",
    options: ["Swimming", "Sprinting", "Cycling", "Tennis"],
    answer: "Sprinting"
  },
  {
    question: "In which sport do players ride on horses?",
    options: ["Polo", "Hockey", "Archery", "Javelin"],
    answer: "Polo"
  },
  {
    question: "Which sport has positions like goalkeeper, defender, and striker?",
    options: ["Cricket", "Basketball", "Football", "Badminton"],
    answer: "Football"
  },
  {
    question: "What sport uses a small white ball and 18 holes?",
    options: ["Baseball", "Tennis", "Golf", "Hockey"],
    answer: "Golf"
  },
  {
    question: "Which Indian city hosted the 2010 Commonwealth Games?",
    options: ["Mumbai", "Chennai", "Delhi", "Kolkata"],
    answer: "Delhi"
  },
  {
    question: "What equipment is needed for boxing?",
    options: ["Helmet", "Gloves", "Racket", "Bat"],
    answer: "Gloves"
  }
],
    medium: [
  {
    question: "Which footballer has won the most Ballon d'Or awards as of 2024?",
    options: ["Cristiano Ronaldo", "Lionel Messi", "Kylian Mbappé", "Neymar Jr."],
    answer: "Lionel Messi"
  },
  {
    question: "How many players are there in a field hockey team during a match?",
    options: ["9", "10", "11", "12"],
    answer: "11"
  },
  {
    question: "In cricket, how many legal deliveries are there in one over?",
    options: ["5", "6", "8", "10"],
    answer: "6"
  },
  {
    question: "Which Grand Slam tennis tournament is played on a clay court?",
    options: ["Australian Open", "Wimbledon", "French Open", "US Open"],
    answer: "French Open"
  },
  {
    question: "Which country has won the most FIFA World Cups?",
    options: ["Germany", "Argentina", "Brazil", "Italy"],
    answer: "Brazil"
  },
  {
    question: "Which Indian player is known for scoring a double century in ODI cricket?",
    options: ["Rahul Dravid", "Virender Sehwag", "MS Dhoni", "Harbhajan Singh"],
    answer: "Virender Sehwag"
  },
  {
    question: "What is the maximum break in a game of snooker?",
    options: ["155", "150", "147", "140"],
    answer: "147"
  },
  {
    question: "Which country has won the most Olympic gold medals in hockey?",
    options: ["Germany", "Australia", "India", "Netherlands"],
    answer: "India"
  },
  {
    question: "Which tennis player is known as the \"King of Clay\"?",
    options: ["Novak Djokovic", "Roger Federer", "Rafael Nadal", "Andy Murray"],
    answer: "Rafael Nadal"
  },
  {
    question: "In cricket, what is the term for scoring 100 runs by a batsman in a single innings?",
    options: ["Over", "Century", "Fifty", "Double"],
    answer: "Century"
  },
  {
    question: "What is the standard distance of a marathon race?",
    options: ["21.1 km", "40 km", "42.195 km", "45 km"],
    answer: "42.195 km"
  },
  {
    question: "Which NFL team has won the most Super Bowl titles?",
    options: ["New York Giants", "Dallas Cowboys", "New England Patriots", "Green Bay Packers"],
    answer: "New England Patriots"
  },
  {
    question: "Which Indian hockey legend is nicknamed “The Wizard”?",
    options: ["Sandeep Singh", "Dhyan Chand", "Dhanraj Pillay", "PR Sreejesh"],
    answer: "Dhyan Chand"
  },
  {
    question: "In football, what does VAR stand for?",
    options: ["Video Accuracy Replay", "Verified Action Review", "Video Assistant Referee", "Virtual Angle Recorder"],
    answer: "Video Assistant Referee"
  },
  {
    question: "Who was the first Indian to win an individual Olympic gold medal?",
    options: ["Abhinav Bindra", "Leander Paes", "Neeraj Chopra", "Rajyavardhan Rathore"],
    answer: "Abhinav Bindra"
  },
  {
    question: "In which sport is the Davis Cup awarded?",
    options: ["Tennis", "Cricket", "Golf", "Baseball"],
    answer: "Tennis"
  },
  {
    question: "Which team won the ICC Cricket World Cup in 2019?",
    options: ["Australia", "New Zealand", "England", "India"],
    answer: "England"
  },
  {
    question: "Which athlete holds the world record for the men’s 100-meter sprint?",
    options: ["Carl Lewis", "Usain Bolt", "Yohan Blake", "Justin Gatlin"],
    answer: "Usain Bolt"
  },
  {
    question: "Which country hosts the Tour de France cycling race?",
    options: ["Italy", "Germany", "Switzerland", "France"],
    answer: "France"
  },
  {
    question: "In which sport is the term “birdie” used?",
    options: ["Cricket", "Tennis", "Badminton", "Golf"],
    answer: "Golf"
  }
],
    difficult: [
  {
    question: "Who was the captain of the Indian cricket team during the 1983 World Cup victory?",
    options: ["Sunil Gavaskar", "Kapil Dev", "Ravi Shastri", "Mohinder Amarnath"],
    answer: "Kapil Dev"
  },
  {
    question: "Which football club has won the most UEFA Champions League titles as of 2024?",
    options: ["AC Milan", "FC Barcelona", "Manchester United", "Real Madrid"],
    answer: "Real Madrid"
  },
  {
    question: "Who holds the record for the fastest century in ODI cricket?",
    options: ["Virat Kohli", "Chris Gayle", "AB de Villiers", "Sanath Jayasuriya"],
    answer: "AB de Villiers"
  },
  {
    question: "Which tennis player completed the Calendar Grand Slam in 1988?",
    options: ["Steffi Graf", "Serena Williams", "Martina Navratilova", "Billie Jean King"],
    answer: "Steffi Graf"
  },
  {
    question: "How many Olympic medals has India won in hockey (as of 2024)?",
    options: ["8 Gold, 1 Silver, 3 Bronze", "10 Gold, 2 Silver, 2 Bronze", "8 Gold, 2 Silver, 3 Bronze", "9 Gold, 2 Silver, 4 Bronze"],
    answer: "8 Gold, 2 Silver, 3 Bronze"
  },
  {
    question: "In which country was the first FIFA World Cup held in 1930?",
    options: ["Brazil", "Argentina", "France", "Uruguay"],
    answer: "Uruguay"
  },
  {
    question: "Which cricketer was the first to score a double century in a men's ODI match?",
    options: ["Virender Sehwag", "Chris Gayle", "Sachin Tendulkar", "Rohit Sharma"],
    answer: "Sachin Tendulkar"
  },
  {
    question: "Who won the men’s singles title at the French Open 2020?",
    options: ["Novak Djokovic", "Dominic Thiem", "Rafael Nadal", "Daniil Medvedev"],
    answer: "Rafael Nadal"
  },
  {
    question: "What is the regulation size of a football (soccer) goal?",
    options: ["7.32 m x 2.44 m", "8 m x 2 m", "6.5 m x 2.5 m", "7 m x 2.5 m"],
    answer: "7.32 m x 2.44 m"
  },
  {
    question: "Which country won the most medals at the Tokyo 2020 Olympics?",
    options: ["China", "USA", "Japan", "Russia"],
    answer: "USA"
  },
  {
    question: "Which Indian badminton player won silver at the 2016 Olympics?",
    options: ["Saina Nehwal", "PV Sindhu", "Jwala Gutta", "Ashwini Ponnappa"],
    answer: "PV Sindhu"
  },
  {
    question: "What is the maximum weight allowed for a Formula 1 car including the driver (as per 2024 regulations)?",
    options: ["752 kg", "798 kg", "828 kg", "900 kg"],
    answer: "828 kg"
  },
  {
    question: "Who was the first player to score 10,000 runs in Test cricket?",
    options: ["Brian Lara", "Sunil Gavaskar", "Sachin Tendulkar", "Allan Border"],
    answer: "Sunil Gavaskar"
  },
  {
    question: "Which country won the Hockey World Cup in 2018?",
    options: ["Belgium", "Australia", "India", "Netherlands"],
    answer: "Belgium"
  },
  {
    question: "In which year was the first modern Olympic Games held?",
    options: ["1896", "1900", "1888", "1912"],
    answer: "1896"
  },
  {
    question: "Which footballer scored the “Hand of God” goal?",
    options: ["Diego Maradona", "Pelé", "Zinedine Zidane", "Ronaldinho"],
    answer: "Diego Maradona"
  },
  {
    question: "Which Indian female athlete became World Champion in boxing multiple times?",
    options: ["Lovlina Borgohain", "Nikhat Zareen", "MC Mary Kom", "Sarita Devi"],
    answer: "MC Mary Kom"
  },
  {
    question: "In which sport is the Thomas Cup awarded?",
    options: ["Tennis", "Badminton", "Volleyball", "Wrestling"],
    answer: "Badminton"
  },
  {
    question: "Who won the ICC Men’s T20 World Cup in 2022?",
    options: ["Pakistan", "England", "India", "Australia"],
    answer: "England"
  },
  {
    question: "Which athlete won 4 gold medals in athletics at the 1936 Berlin Olympics?",
    options: ["Jesse Owens", "Carl Lewis", "Emil Zátopek", "Mark Spitz"],
    answer: "Jesse Owens"
  }
],
   hard: [
  {
    question: "Which cricketer has the highest individual score in a Test match innings as of 2024?",
    options: ["Brian Lara", "Don Bradman", "Virat Kohli", "Matthew Hayden"],
    answer: "Brian Lara"
  },
  {
    question: "Which footballer won the Golden Boot in the 1998 FIFA World Cup?",
    options: ["Ronaldo (Brazil)", "Thierry Henry", "Davor Šuker", "Zinedine Zidane"],
    answer: "Davor Šuker"
  },
  {
    question: "In tennis, who was the first male player to achieve a Career Golden Slam (all 4 majors + Olympic gold)?",
    options: ["Rafael Nadal", "Roger Federer", "Andre Agassi", "Novak Djokovic"],
    answer: "Andre Agassi"
  },
  {
    question: "Which Indian bowler took a hat-trick in the 2019 Cricket World Cup?",
    options: ["Jasprit Bumrah", "Mohammed Shami", "Bhuvneshwar Kumar", "Yuzvendra Chahal"],
    answer: "Mohammed Shami"
  },
  {
    question: "Which nation has won the most Rugby World Cups (as of 2023)?",
    options: ["New Zealand", "England", "Australia", "South Africa"],
    answer: "South Africa"
  },
  {
    question: "Which hockey player holds the record for the most international goals?",
    options: ["Jamie Dwyer", "Sohail Abbas", "Dhanraj Pillay", "Dhyan Chand"],
    answer: "Sohail Abbas"
  },
  {
    question: "What is the highest break possible in a frame of snooker including a free ball?",
    options: ["147", "155", "150", "149"],
    answer: "155"
  },
  {
    question: "Which country won gold in men's field hockey at the 2020 Tokyo Olympics?",
    options: ["India", "Belgium", "Australia", "Netherlands"],
    answer: "Belgium"
  },
  {
    question: "Which team won the UEFA Euro 1992 tournament despite not initially qualifying?",
    options: ["Denmark", "Germany", "Greece", "Sweden"],
    answer: "Denmark"
  },
  {
    question: "Who was the first woman to win Olympic gold in boxing?",
    options: ["Claressa Shields", "Mary Kom", "Nicola Adams", "Katie Taylor"],
    answer: "Nicola Adams"
  },
  {
    question: "Which cricketer bowled the fastest delivery ever recorded?",
    options: ["Shoaib Akhtar", "Brett Lee", "Shaun Tait", "Jeff Thomson"],
    answer: "Shoaib Akhtar"
  },
  {
    question: "Which tennis Grand Slam had its first tournament in 1877?",
    options: ["US Open", "French Open", "Wimbledon", "Australian Open"],
    answer: "Wimbledon"
  },
  {
    question: "Which Indian athlete set a new national record in men's javelin before Neeraj Chopra?",
    options: ["Devendra Jhajharia", "Shivpal Singh", "Anil Kumar", "Rajinder Singh"],
    answer: "Shivpal Singh"
  },
  {
    question: "What is the official distance of the Olympic triathlon?",
    options: [
      "1.5 km swim, 40 km bike, 10 km run",
      "2 km swim, 30 km bike, 15 km run",
      "1 km swim, 50 km bike, 5 km run",
      "2.5 km swim, 20 km bike, 10 km run"
    ],
    answer: "1.5 km swim, 40 km bike, 10 km run"
  },
  {
    question: "Which Indian female shooter won a silver medal at the 2020 Tokyo Olympics?",
    options: ["Manu Bhaker", "Apurvi Chandela", "Rahi Sarnobat", "None (India won no silver in shooting at Tokyo 2020)"],
    answer: "None (India won no silver in shooting at Tokyo 2020)"
  },
  {
    question: "Which footballer has the most career goals in official matches?",
    options: ["Pelé", "Cristiano Ronaldo", "Lionel Messi", "Josef Bican"],
    answer: "Cristiano Ronaldo"
  },
  {
    question: "Which cricket team has the longest unbeaten streak in World Cup matches?",
    options: ["India", "Australia", "South Africa", "England"],
    answer: "Australia"
  },
  {
    question: "Which NBA team holds the record for most championships?",
    options: ["Chicago Bulls", "Los Angeles Lakers", "Golden State Warriors", "Boston Celtics"],
    answer: "Boston Celtics"
  },
  {
    question: "Which female athlete won medals in both Summer and Winter Olympics?",
    options: ["Florence Griffith Joyner", "Clara Hughes", "Allyson Felix", "Jackie Joyner-Kersee"],
    answer: "Clara Hughes"
  },
  {
    question: "Which cricketer has taken the most international wickets across all formats?",
    options: ["Shane Warne", "Anil Kumble", "Muttiah Muralitharan", "James Anderson"],
    answer: "Muttiah Muralitharan"
  }
]
  },
  program: {
    easy: [
  {
    question: "Which language is primarily used for web page structure?",
    options: ["Python", "HTML", "Java", "C++"],
    answer: "HTML"
  },
  {
    question: "Which language is known as the \"father of C++\"?",
    options: ["Dennis Ritchie", "Bjarne Stroustrup", "James Gosling", "Guido van Rossum"],
    answer: "Bjarne Stroustrup"
  },
  {
    question: "Which language is used for Android app development?",
    options: ["Swift", "Kotlin", "Ruby", "PHP"],
    answer: "Kotlin"
  },
  {
    question: "Which language is commonly used for data science and machine learning?",
    options: ["Python", "JavaScript", "C#", "HTML"],
    answer: "Python"
  },
  {
    question: "Which language is used to style web pages?",
    options: ["CSS", "Java", "SQL", "C"],
    answer: "CSS"
  },
  {
    question: "What does SQL stand for?",
    options: ["Structured Query Language", "Simple Query Language", "Strong Question Language", "Structured Question Logic"],
    answer: "Structured Query Language"
  },
  {
    question: "Which language runs in the browser?",
    options: ["JavaScript", "Python", "C++", "Java"],
    answer: "JavaScript"
  },
  {
    question: "Which programming language is known for its use in iOS app development?",
    options: ["Swift", "PHP", "Ruby", "Kotlin"],
    answer: "Swift"
  },
  {
    question: "Which language is used for backend web development and shares its name with a gemstone?",
    options: ["Ruby", "Pearl", "Python", "Jade"],
    answer: "Ruby"
  },
  {
    question: "Which language was developed by Microsoft?",
    options: ["Java", "C#", "PHP", "Perl"],
    answer: "C#"
  },
  {
    question: "Which programming language uses indentation as part of its syntax?",
    options: ["Java", "Python", "C++", "Ruby"],
    answer: "Python"
  },
  {
    question: "Which language is widely used for system programming?",
    options: ["JavaScript", "C", "HTML", "PHP"],
    answer: "C"
  },
  {
    question: "Which language is known for building dynamic web pages and is embedded in HTML?",
    options: ["PHP", "Python", "Java", "SQL"],
    answer: "PHP"
  },
  {
    question: "Which language compiles to bytecode that runs on the Java Virtual Machine (JVM)?",
    options: ["Java", "C#", "JavaScript", "Swift"],
    answer: "Java"
  },
  {
    question: "Which language is primarily used for creating iOS and macOS apps?",
    options: ["Kotlin", "Swift", "Ruby", "JavaScript"],
    answer: "Swift"
  },
  {
    question: "Which language was originally created for statistical computing?",
    options: ["Python", "R", "Julia", "Perl"],
    answer: "R"
  },
  {
    question: "Which language is used for querying databases?",
    options: ["Java", "SQL", "C++", "HTML"],
    answer: "SQL"
  },
  {
    question: "Which language is best known for Artificial Intelligence and has a large community?",
    options: ["Python", "COBOL", "FORTRAN", "Pascal"],
    answer: "Python"
  },
  {
    question: "Which language was developed at Bell Labs in the early 1970s?",
    options: ["Java", "C", "Python", "Ruby"],
    answer: "C"
  },
  {
    question: "Which language is primarily used for scripting on websites and can manipulate HTML elements?",
    options: ["JavaScript", "SQL", "PHP", "C#"],
    answer: "JavaScript"
  }
],
    medium: [
  {
    question: "Which programming paradigm does Java primarily follow?",
    options: ["Procedural", "Object-Oriented", "Functional", "Logic"],
    answer: "Object-Oriented"
  },
  {
    question: "In Python, what is the output of len([1, 2, 3, 4])?",
    options: ["3", "4", "5", "Error"],
    answer: "4"
  },
  {
    question: "What is the main purpose of the ‘interface’ keyword in Java?",
    options: [
      "To implement multiple inheritance",
      "To define constants",
      "To define abstract methods without implementation",
      "To create objects"
    ],
    answer: "To define abstract methods without implementation"
  },
  {
    question: "Which keyword is used to declare a constant in C++?",
    options: ["var", "const", "final", "static"],
    answer: "const"
  },
  {
    question: "In JavaScript, which method converts a JSON string into a JavaScript object?",
    options: ["JSON.parse()", "JSON.stringify()", "JSON.convert()", "JSON.toObject()"],
    answer: "JSON.parse()"
  },
  {
    question: "What is the output of the following Python code snippet? print(type({}))",
    options: [
      "<class 'dict'>",
      "<class 'set'>",
      "<class 'list'>",
      "<class 'tuple'>"
    ],
    answer: "<class 'dict'>"
  },
  {
    question: "Which of these is NOT a valid access modifier in Java?",
    options: ["public", "private", "protected", "internal"],
    answer: "internal"
  },
  {
    question: "In C, what is the size of the int data type on a 64-bit system typically?",
    options: ["2 bytes", "4 bytes", "8 bytes", "Depends on compiler"],
    answer: "4 bytes"
  },
  {
    question: "Which programming language uses ‘duck typing’?",
    options: ["Java", "C++", "Python", "Swift"],
    answer: "Python"
  },
  {
    question: "In SQL, which command is used to remove all rows from a table without logging individual row deletions?",
    options: ["DELETE", "DROP", "TRUNCATE", "REMOVE"],
    answer: "TRUNCATE"
  },
  {
    question: "What does the term ‘immutability’ mean in programming?",
    options: [
      "Objects cannot be changed after creation",
      "Objects can be modified anytime",
      "Objects get deleted after use",
      "Objects are stored in temporary memory"
    ],
    answer: "Objects cannot be changed after creation"
  },
  {
    question: "Which of these languages supports both procedural and object-oriented programming?",
    options: ["Python", "C", "Assembly", "HTML"],
    answer: "Python"
  },
  {
    question: "What is the default value of a boolean variable in Java?",
    options: ["true", "false", "0", "null"],
    answer: "false"
  },
  {
    question: "In JavaScript, what does the ‘===’ operator do?",
    options: [
      "Checks equality of value only",
      "Checks equality of type only",
      "Checks equality of value and type",
      "Assigns a value"
    ],
    answer: "Checks equality of value and type"
  },
  {
    question: "Which keyword in Python is used to handle exceptions?",
    options: ["catch", "try", "except", "handle"],
    answer: "except"
  },
  {
    question: "In C++, which feature allows the same function name with different parameters?",
    options: [
      "Function Overloading",
      "Operator Overloading",
      "Inheritance",
      "Encapsulation"
    ],
    answer: "Function Overloading"
  },
  {
    question: "Which of the following is a JavaScript framework?",
    options: ["Django", "Angular", "Flask", "Laravel"],
    answer: "Angular"
  },
  {
    question: "What does ‘git clone’ do?",
    options: [
      "Deletes a repository",
      "Creates a new branch",
      "Copies a repository to local machine",
      "Merges two branches"
    ],
    answer: "Copies a repository to local machine"
  },
  {
    question: "Which of these is a Python web framework?",
    options: ["React", "Flask", "Vue", "Laravel"],
    answer: "Flask"
  },
  {
    question: "In CSS, what does ‘padding’ do?",
    options: [
      "Adds space inside an element’s border",
      "Adds space outside an element’s border",
      "Changes the font size",
      "Changes the background color"
    ],
    answer: "Adds space inside an element’s border"
  }
],
    difficult: [
  {
    question: "In C++, what is the “diamond problem” related to?",
    options: ["Function Overloading", "Multiple Inheritance", "Templates", "Operator Overloading"],
    answer: "Multiple Inheritance"
  },
  {
    question: "Which garbage collection algorithm uses a \"mark and sweep\" approach?",
    options: ["Reference Counting", "Generational GC", "Mark-and-Sweep", "Copying GC"],
    answer: "Mark-and-Sweep"
  },
  {
    question: "In Python, what does the yield keyword do?",
    options: [
      "Stops a function",
      "Returns a value and pauses the function, resuming later",
      "Declares a generator variable",
      "Raises an exception"
    ],
    answer: "Returns a value and pauses the function, resuming later"
  },
  {
    question: "Which of the following is NOT a characteristic of functional programming?",
    options: ["Immutability", "First-class functions", "Side-effects", "Pure functions"],
    answer: "Side-effects"
  },
  {
    question: "In Java, what is the purpose of the volatile keyword?",
    options: [
      "To make a variable constant",
      "To ensure visibility of changes to variables across threads",
      "To declare a method abstract",
      "To prevent inheritance"
    ],
    answer: "To ensure visibility of changes to variables across threads"
  },
  {
    question: "Which data structure is used in Depth-First Search (DFS) traversal of graphs?",
    options: ["Queue", "Stack", "Hash Table", "Tree"],
    answer: "Stack"
  },
  {
    question: "In C, which function is used to dynamically allocate memory?",
    options: ["malloc()", "alloc()", "calloc()", "new()"],
    answer: "malloc()"
  },
  {
    question: "Which of the following is a statically typed language?",
    options: ["JavaScript", "Python", "Java", "Ruby"],
    answer: "Java"
  },
  {
    question: "What does the acronym REST stand for in web services?",
    options: [
      "Representational State Transfer",
      "Remote State Transfer",
      "Representational Standard Transfer",
      "Remote Service Transfer"
    ],
    answer: "Representational State Transfer"
  },
  {
    question: "In JavaScript, which of the following is true about closures?",
    options: [
      "They allow a function to access variables from another unrelated function",
      "They allow a function to retain access to its lexical scope even when executed outside that scope",
      "They prevent memory leaks",
      "They are used only in object methods"
    ],
    answer: "They allow a function to retain access to its lexical scope even when executed outside that scope"
  },
  {
    question: "Which language introduced the concept of \"coroutines\"?",
    options: ["Python", "C#", "Simula", "Java"],
    answer: "Simula"
  },
  {
    question: "Which C++ feature allows defining functions with the same name but different parameter lists?",
    options: ["Polymorphism", "Encapsulation", "Abstraction", "Function Overloading"],
    answer: "Function Overloading"
  },
  {
    question: "In SQL, what does the acronym ACID stand for?",
    options: [
      "Atomicity, Consistency, Isolation, Durability",
      "Atomicity, Control, Integrity, Durability",
      "Accuracy, Consistency, Isolation, Durability",
      "Atomicity, Consistency, Isolation, Data"
    ],
    answer: "Atomicity, Consistency, Isolation, Durability"
  },
  {
    question: "Which of these is NOT a valid Python data type?",
    options: ["tuple", "dictionary", "arraylist", "set"],
    answer: "arraylist"
  },
  {
    question: "What is the time complexity of accessing an element in a hash table?",
    options: ["O(n)", "O(log n)", "O(1) average case", "O(n^2)"],
    answer: "O(1) average case"
  },
  {
    question: "Which of these is a feature of the Rust programming language?",
    options: ["Garbage Collection", "Ownership System", "Dynamic Typing", "No Concurrency Support"],
    answer: "Ownership System"
  },
  {
    question: "In Java, what is the difference between == and .equals()?",
    options: [
      "== compares object references, .equals() compares object content",
      "== compares object content, .equals() compares references",
      "Both do the same thing",
      ".equals() is only for primitive types"
    ],
    answer: "== compares object references, .equals() compares object content"
  },
  {
    question: "Which of the following is NOT a valid HTTP method?",
    options: ["GET", "PUSH", "POST", "DELETE"],
    answer: "PUSH"
  },
  {
    question: "Which programming language is known for its \"write once, run anywhere\" feature?",
    options: ["C++", "Java", "Python", "JavaScript"],
    answer: "Java"
  },
  {
    question: "Which paradigm is NOT supported by Scala?",
    options: ["Object-Oriented", "Functional", "Procedural", "Logical"],
    answer: "Logical"
  }
],
    hard: [
  {
    question: "In C++, what is the purpose of the decltype keyword?",
    options: [
      "To declare a variable with a type deduced from an expression",
      "To explicitly convert types",
      "To define template parameters",
      "To declare constant expressions"
    ],
    answer: "To declare a variable with a type deduced from an expression"
  },
  {
    question: "Which of the following best describes \"monads\" in functional programming?",
    options: [
      "A type of variable",
      "A design pattern to handle side effects and chain operations",
      "A class inheritance hierarchy",
      "A method to optimize loops"
    ],
    answer: "A design pattern to handle side effects and chain operations"
  },
  {
    question: "In Python, what is the difference between @staticmethod and @classmethod decorators?",
    options: [
      "@staticmethod takes the class as the first argument, @classmethod does not",
      "@staticmethod does not take the instance or class as the first argument, @classmethod takes the class",
      "Both are identical",
      "Both require the instance as the first argument"
    ],
    answer: "@staticmethod does not take the instance or class as the first argument, @classmethod takes the class"
  },
  {
    question: "In Java, what is the role of the transient keyword?",
    options: [
      "To mark a variable as static",
      "To exclude a variable from serialization",
      "To mark a method as synchronized",
      "To indicate deprecated methods"
    ],
    answer: "To exclude a variable from serialization"
  },
  {
    question: "What is tail call optimization in functional languages?",
    options: [
      "Optimizing loops to reduce memory usage",
      "Transforming recursive calls in tail position to iterative loops to save stack space",
      "Compiling code at runtime",
      "Using multiple threads to run functions"
    ],
    answer: "Transforming recursive calls in tail position to iterative loops to save stack space"
  },
  {
    question: "Which of the following describes the purpose of the Rust borrow checker?",
    options: [
      "Manages memory allocation dynamically",
      "Enforces ownership and borrowing rules at compile time to ensure memory safety",
      "Collects garbage periodically",
      "Checks syntax errors in Rust code"
    ],
    answer: "Enforces ownership and borrowing rules at compile time to ensure memory safety"
  },
  {
    question: "What is the main difference between interface and abstract class in Java?",
    options: [
      "Interface can have implemented methods, abstract class cannot",
      "Abstract class supports multiple inheritance, interface does not",
      "Interface supports multiple inheritance, abstract class does not",
      "No difference"
    ],
    answer: "Interface supports multiple inheritance, abstract class does not"
  },
  {
    question: "In Haskell, what does the >>= operator do?",
    options: [
      "Represents function composition",
      "The bind operator to chain monadic operations",
      "Logical AND operator",
      "List concatenation"
    ],
    answer: "The bind operator to chain monadic operations"
  },
  {
    question: "What is the significance of volatile keyword in C++11 memory model?",
    options: [
      "It ensures variable is always stored in cache",
      "It indicates that the variable can be modified by multiple threads without synchronization",
      "It prevents compiler from optimizing accesses to the variable",
      "It locks the variable for exclusive access"
    ],
    answer: "It prevents compiler from optimizing accesses to the variable"
  },
  {
    question: "Which of these is NOT a feature of the Go programming language?",
    options: [
      "Goroutines",
      "Manual memory management",
      "Channels for communication",
      "Garbage collection"
    ],
    answer: "Manual memory management"
  },
  {
    question: "In Python’s asyncio library, what is the difference between async def and def functions?",
    options: [
      "async def functions are synchronous, def are asynchronous",
      "async def functions return coroutine objects and can be awaited",
      "No difference",
      "def functions can use await keyword, async def cannot"
    ],
    answer: "async def functions return coroutine objects and can be awaited"
  },
  {
    question: "In Java, what does the volatile keyword guarantee?",
    options: [
      "Atomicity of variable updates",
      "Visibility of changes across threads but not atomicity",
      "Mutual exclusion",
      "Both atomicity and visibility"
    ],
    answer: "Visibility of changes across threads but not atomicity"
  },
  {
    question: "Which of these is true about C++ templates?",
    options: [
      "Templates are instantiated at runtime",
      "Templates allow compile-time polymorphism",
      "Templates cannot be specialized",
      "Templates are the same as macros"
    ],
    answer: "Templates allow compile-time polymorphism"
  },
  {
    question: "What is the role of a \"typeclass\" in languages like Haskell?",
    options: [
      "To define a blueprint for classes",
      "To define functions that can operate on different types generically",
      "To implement inheritance",
      "To handle exceptions"
    ],
    answer: "To define functions that can operate on different types generically"
  },
  {
    question: "Which of the following is NOT a valid way to declare a lambda expression in Java 8?",
    options: [
      "(int x) -> x * x",
      "x -> { return x * x; }",
      "() -> System.out.println(\"Hello\")",
      "lambda x: x * x"
    ],
    answer: "lambda x: x * x"
  },
  {
    question: "Which feature allows JavaScript to support asynchronous programming?",
    options: [
      "Promises",
      "Generators",
      "Callbacks",
      "All of the above"
    ],
    answer: "All of the above"
  },
  {
    question: "In C++, what does the constexpr specifier do?",
    options: [
      "Declares a variable as constant at runtime",
      "Specifies that the value or function can be evaluated at compile time",
      "Indicates a volatile variable",
      "Marks a deprecated function"
    ],
    answer: "Specifies that the value or function can be evaluated at compile time"
  },
  {
    question: "What is the main difference between “shallow copy” and “deep copy”?",
    options: [
      "Shallow copy copies only the object reference, deep copy copies the entire object recursively",
      "Deep copy copies only the reference, shallow copy copies the whole object",
      "Both are same",
      "Shallow copy is slower than deep copy"
    ],
    answer: "Shallow copy copies only the object reference, deep copy copies the entire object recursively"
  },
  {
    question: "Which of these best describes \"currying\" in functional programming?",
    options: [
      "Breaking a function with multiple arguments into a series of functions each with a single argument",
      "Combining two functions into one",
      "Optimizing recursive functions",
      "Converting functions to methods"
    ],
    answer: "Breaking a function with multiple arguments into a series of functions each with a single argument"
  },
  {
    question: "In Erlang, how is concurrency achieved?",
    options: [
      "Threads",
      "Processes communicating via message passing",
      "Asynchronous callbacks",
      "Event loops"
    ],
    answer: "Processes communicating via message passing"
  }
]
  }
};