// 🔁 Shuffle any array
function shuffleArray(arr) {
  const array = arr.slice();
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// 🌟 Score message
function getScoreMessage(score) {
  if (score === 10) return "🎉 Perfect Score! You're a quiz master!";
  if (score >= 8) return "👏 Great job!";
  if (score >= 5) return "🙂 Nice try!";
  return "😅 Keep practicing!";
}

// 🏅 League based on totalCorrect
function getLeague(totalCorrect) {
  if (totalCorrect >= 90) return "Diamond";
  if (totalCorrect >= 70) return "Platinum";
  if (totalCorrect >= 50) return "Gold";
  if (totalCorrect >= 30) return "Silver";
  return "Bronze";
}

// 🧠 Store quiz result for current user
function storeResult(score) {
  let currentUser = JSON.parse(localStorage.getItem("currentUser"));
  let users = JSON.parse(localStorage.getItem("users") || "[]");

  if (!currentUser) {
    alert("User not logged in!");
    return;
  }

  // Initialize totalCorrect if not present
  if (currentUser.totalCorrect === undefined) {
    currentUser.totalCorrect = 0;
  }

  // Add current correct answers
  currentUser.totalCorrect += score;

  // Update league
  currentUser.league = getLeague(currentUser.totalCorrect);

  // Update users array
  users = users.map(u => {
    if (u.email === currentUser.email) {
      u.totalCorrect = currentUser.totalCorrect;
      u.league = currentUser.league;
    }
    return u;
  });

  // Save back
  localStorage.setItem("currentUser", JSON.stringify(currentUser));
  localStorage.setItem("users", JSON.stringify(users));

  // Optionally save general stats
  const totalAttempts = parseInt(localStorage.getItem("totalAttempts") || "0") + 1;
  localStorage.setItem("totalAttempts", totalAttempts);
  localStorage.setItem("lastScore", score);
  localStorage.setItem("lastLeague", currentUser.league);
}

// ✅ Login form handler
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", function(e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    let users = JSON.parse(localStorage.getItem("users") || "[]");
    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
      alert("Welcome, " + user.username + "!");
      localStorage.setItem("currentUser", JSON.stringify(user));
      // Example: window.location.href = "quiz.html";
    } else {
      alert("Invalid email or password!");
    }
  });
}

// ✅ Register form handler
const registerForm = document.getElementById("registerForm");
if (registerForm) {
  registerForm.addEventListener("submit", function(e) {
    e.preventDefault();

    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    let users = JSON.parse(localStorage.getItem("users") || "[]");
    if (users.some(u => u.email === email)) {
      alert("Email already registered!");
      return;
    }

    const newUser = {
      username,
      email,
      password,
      totalCorrect: 0, // ✅ Correct field
      league: "Bronze"
    };

    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));

    alert("Registration successful! Please login.");
    // Optional: switch to login form automatically
  });
}
