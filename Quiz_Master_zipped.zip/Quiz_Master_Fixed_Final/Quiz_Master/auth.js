// auth.js

// Save user data to localStorage
function registerUser(username, email, password) {
    let users = JSON.parse(localStorage.getItem("users") || "[]");

    // Check if email already exists
    if (users.some(user => user.email === email)) {
        alert("Email already registered!");
        return false;
    }

    // Add new user
    users.push({ username, email, password, preferredLevel: "Easy", league: "Bronze" });
    localStorage.setItem("users", JSON.stringify(users));

    alert("Registration successful!");
    return true;
}

// Login user
function loginUser(email, password) {
    let users = JSON.parse(localStorage.getItem("users") || "[]");
    let user = users.find(u => u.email === email && u.password === password);

    if (user) {
        localStorage.setItem("currentUser", JSON.stringify(user));
        alert("Login successful!");
        return true;
    } else {
        alert("Invalid email or password!");
        return false;
    }
}

// Get current user
function getCurrentUser() {
    return JSON.parse(localStorage.getItem("currentUser"));
}

// Update profile
function updateProfile(newUsername, newPreferredLevel) {
    let users = JSON.parse(localStorage.getItem("users") || "[]");
    let currentUser = JSON.parse(localStorage.getItem("currentUser"));

    if (!currentUser) {
        alert("No user logged in!");
        return;
    }

    // Update data
    users = users.map(user => {
        if (user.email === currentUser.email) {
            user.username = newUsername;
            user.preferredLevel = newPreferredLevel;
            localStorage.setItem("currentUser", JSON.stringify(user)); // Update current user too
        }
        return user;
    });

    localStorage.setItem("users", JSON.stringify(users));
    alert("Profile updated successfully!");
}
