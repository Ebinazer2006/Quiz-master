
    document.querySelectorAll('.particle-button').forEach(button => {
  const particlesContainer = button.querySelector('.particles');
  // Store the original onclick destination
  const href = button.getAttribute('onclick')?.match(/window\.location\.href='([^']+)'/)?.[1];

  button.addEventListener('click', function(e) {
    e.preventDefault(); // Prevent immediate navigation

    const rect = button.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    for (let i = 0; i < 20; i++) {
      const particle = document.createElement('div');
      particle.classList.add('particle');
      particle.style.left = `${x}px`;
      particle.style.top = `${y}px`;
      const dx = `${Math.random() * 200 - 100}px`;
      const dy = `${Math.random() * 200 - 100}px`;
      particle.style.setProperty('--dx', dx);
      particle.style.setProperty('--dy', dy);
      particlesContainer.appendChild(particle);
      setTimeout(() => {
        particle.remove();
      }, 700);
    }

    // Delay navigation until after the effect
    if (href) {
      setTimeout(() => {
        window.location.href = href;
      }, 700); // Match the particle animation duration
    }
  });
  // Remove the inline onclick to avoid double navigation
  button.removeAttribute('onclick');
});